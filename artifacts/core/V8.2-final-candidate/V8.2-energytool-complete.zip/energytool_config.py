"""Настройки ядра из серверного окружения, без чтения пользовательских сообщений."""

from dataclasses import dataclass, field
import math
import os
from pathlib import Path
from urllib.parse import urlsplit

from core_contract import CoreUnavailable


def first_env(*names: str) -> str:
    """Платформенные имена имеют тот же приоритет, что указан в инструкции."""
    for name in names:
        value = os.getenv(name, '').strip()
        # В примере платформы имя переменной служит заглушкой для пустого поля.
        if value and value != name:
            return value
    return ''


def redact_secret(value, secret):
    """Удаляем серверный секрет из значений до JSON-экранирования.

    Структурные имена полей не являются пользовательскими данными. Функция
    возвращает копию, поэтому общие документы и история клиента не изменяются.
    """
    if not secret:
        return value
    if isinstance(value, str):
        return value.replace(secret, '[секрет удалён]')
    if isinstance(value, list):
        return [redact_secret(item, secret) for item in value]
    if isinstance(value, dict):
        return {key: redact_secret(item, secret) for key, item in value.items()}
    return value


def number(name: str, default: str, minimum: float, maximum: float, integer=False):
    """Ошибку конфигурации показываем по имени поля, не раскрывая его значение."""
    try:
        value = int(first_env(name) or default) if integer else float(first_env(name) or default)
        if not math.isfinite(value) or not minimum <= value <= maximum:
            raise ValueError
        return value
    except (ValueError, OverflowError):
        raise CoreUnavailable(f'Некорректная настройка {name}') from None


@dataclass(frozen=True)
class Settings:
    """Неизменяемая конфигурация; секрет исключён из repr и диагностических отчётов."""
    data_dir: Path
    kb_path: Path | None = None
    demo: bool = False
    base_url: str = field(default='', repr=False)
    api_key: str = field(default='', repr=False)
    model: str = ''
    temperature: float = 0.1
    max_tokens: int = 1200
    top_k: int = 5
    chunk_chars: int = 1800
    context_chars: int = 14000
    history_chars: int = 16000
    request_seconds: float = 100
    network_seconds: float = 85
    retries: int = 2
    max_workers: int = 4
    reranker_model: str = ''
    review_answers: bool = True

    def __post_init__(self):
        """Проверяем лимиты и при прямом создании, не только из окружения.

        Малые положительные бюджеты допустимы для вложенных вызовов и тестов.
        Нулевой семафор, отрицательные повторы и нечисловой дедлайн недопустимы.
        """
        integer_fields = ('max_tokens', 'top_k', 'chunk_chars', 'context_chars',
                          'history_chars', 'max_workers', 'retries')
        for name in integer_fields:
            value = getattr(self, name)
            minimum = 0 if name == 'retries' else 1
            if type(value) is not int or value < minimum:
                raise CoreUnavailable(f'Некорректная настройка {name}')
        for name in ('temperature', 'request_seconds', 'network_seconds'):
            value = getattr(self, name)
            if (type(value) not in {int, float} or not math.isfinite(value)
                    or (value < 0 if name == 'temperature' else value <= 0)):
                raise CoreUnavailable(f'Некорректная настройка {name}')

    @classmethod
    def from_environment(cls):
        """Режим демонстрации включается только CORE_DEMO=true, не автоматически."""
        mode = os.getenv('CORE_DEMO', 'false').lower()
        if mode not in {'true', 'false'}:
            raise CoreUnavailable('CORE_DEMO должен быть true или false')
        review = os.getenv('CORE_REVIEW_ANSWERS', 'true').lower()
        if review not in {'true', 'false'}:
            raise CoreUnavailable('CORE_REVIEW_ANSWERS должен быть true или false')
        data = Path(first_env('DATA_DIR') or 'data').expanduser().resolve()
        configured = os.getenv('CORE_KB_PATH', '').strip()
        kb = Path(configured).expanduser().resolve() if configured else None
        settings = cls(
            data_dir=data, kb_path=kb, demo=mode == 'true',
            base_url=first_env('LLM_BASE_URL', 'OPENAI_BASE_URL', 'BASE_URL'),
            api_key=first_env('LLM_API_KEY', 'OPENAI_API_KEY'),
            model=first_env('LLM_MODEL', 'OPENAI_MODEL', 'GEN_MODEL'),
            temperature=number('TEMPERATURE', '0.1', 0, 2),
            max_tokens=number('MAX_TOKENS', '1200', 1, 16000, True),
            top_k=number('TOP_K', '5', 1, 30, True),
            chunk_chars=number('CORE_CHUNK_CHARS', '1800', 300, 7000, True),
            context_chars=number('CORE_CONTEXT_CHARS', '14000', 2000, 60000, True),
            history_chars=number('CORE_HISTORY_CHARS', '16000', 1000, 60000, True),
            request_seconds=number('CORE_TIMEOUT_SECONDS', '100', 1, 120),
            network_seconds=number('LLM_TIMEOUT_SECONDS', '85', .1, 120),
            retries=number('LLM_MAX_RETRIES', '2', 0, 3, True),
            max_workers=number('MAX_WORKERS', '4', 1, 16, True),
            reranker_model=first_env('RERANKER_MODEL'),
            review_answers=review == 'true',
        )
        if (first_env('CHUNKER') or 'sections') not in {'sections', 'common'}:
            raise CoreUnavailable('Поддерживается CHUNKER=sections или common (смысловое разбиение)')
        if not settings.demo:
            settings.validate_provider()
        return settings

    def validate_provider(self):
        """Адрес и ключ доверяем только окружению, а не результату модели."""
        if not self.base_url or not self.api_key or not self.model:
            raise CoreUnavailable('Нужны LLM_BASE_URL, LLM_API_KEY и LLM_MODEL либо их платформенные аналоги')
        try:
            url = urlsplit(self.base_url)
            # urlsplit откладывает проверку порта до обращения к свойству.
            port = url.port
            valid = (url.scheme in {'http', 'https'} and url.hostname and port != 0 and not url.username
                     and not url.password and not url.query and not url.fragment)
            if not valid or any(not 33 <= ord(c) <= 126 for c in self.api_key):
                raise ValueError
        except ValueError:
            raise CoreUnavailable('Некорректная конфигурация провайдера') from None

    @property
    def completion_url(self):
        """Не добавляем /v1: базовый путь задаёт владелец API."""
        base = self.base_url.rstrip('/')
        return base if base.endswith('/chat/completions') else base + '/chat/completions'
